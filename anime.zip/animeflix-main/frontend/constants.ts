export const proxyFreeUrls = /(gogocdn\.stream)|(manifest\.prod\.boltdns\.net)/;
