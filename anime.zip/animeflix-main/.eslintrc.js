module.exports = {
  root: true,
  extends: ['animeflix'],
  settings: {
    next: {
      rootDir: ['frontend'],
    },
  },
};
