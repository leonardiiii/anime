export * from './dist/generated/aniList';
