export const aniListEndpoint = 'https://graphql.anilist.co';
export const kitsuEndpoint = 'https://kitsu.io/api/graphql';
